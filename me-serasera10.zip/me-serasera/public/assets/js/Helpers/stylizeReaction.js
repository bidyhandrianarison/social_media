export function stylizeReaction(reaction,container){
    if(reaction==='Love'){
        container.className.add("text-red-400")
}
    else if(reaction==="Grr"){
        container.classList.add("");
    }
    else if(reaction==="Haha"){
        container.classList="far fa-laugh-beam"
    }
    else if(reaction==="Like"){
        container.classList="far fa-hand-point-up"
    }


}
