export function iconReaction(reaction,icon){
    if(reaction==='Love'){
        icon.classList="far fa-heart";
}
    else if(reaction==="Grr"){
        icon.classList="far fa-angry"
    }
    else if(reaction==="Haha"){
        icon.classList="far fa-laugh-beam"
    }
    else if(reaction==="Like"){
        icon.classList="far fa-hand-point-up"
    }
}